import java.util.ArrayList;

public class Editora {
    private String nome;
    private long cnpj;

    private static ArrayList<Editora> editoras = new ArrayList<>();

}
