import java.util.ArrayList;

public class Colecao {
    private String nome;
    private Autor autor;

    private static ArrayList<Livro> livros = new ArrayList<>();
    private static ArrayList<Colecao> colecoes = new ArrayList<>();

}
