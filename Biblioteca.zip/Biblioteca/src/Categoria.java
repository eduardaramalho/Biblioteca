public enum Categoria {
    SUSPENSE,
    TERROR,
    POESIA,
    CRONICA,
    CONTO,
    ROMANCE,
    FICCAO,
    FANTASIA
}
