import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
	// write your code here

    }

    public static void menuPessoa(){
        System.out.println("MENU" +
                "1 - Autor" +
                "2 - Cliente" +
                "3 - Funcionário");
        int opcao = sc.nextInt();

        switch (opcao){
            case 1:
            Usuario.menu();
            break;
            case 2:
            Usuario.menu();
            break;
            case 3:
            Usuario.menu();
            break;

            default:
                System.out.println("Opção inválida." );
        }
    }
}
