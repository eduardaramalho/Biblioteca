public class Autor extends Pessoa{
    private String nome;

    public static String menu(){
        return "1 - Ver livros" +
                "2 - Ver livros emprestado" +
                "3 - Emprestar livro" +
                "4 - Cadastrar livro" +
                "5 - Cadastrar autor";
    }


}
