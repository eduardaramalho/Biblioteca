import java.util.ArrayList;

public class Cliente extends Usuario {
    private long cpf;
    private int idade;
    private ArrayList <Livro> livros = new ArrayList<>();

    public Cliente(long cpf, int idade, int senha, String nome) {
        super(cpf, idade, senha, nome);
    }

    @Override
    public String menu(){
        System.out.println("1 - Ver livros" +
                "\n2 - Ver livros emprestados" +
                "\n3 - Emprestar livro" +
                "");
        int opcao = sc.nextInt();
        switch (opcao){
            case 1:
                System.out.println(Livro.getLivros());
            case 2:
                System.out.println(verLivrosEmprestados());
            case 3:
                System.out.println(Emprestimo.emprestarLivro());
        }
        return null;

    }

    @Override
    public ArrayList<Livro> verLivrosEmprestados() {
        return new ArrayList<>();
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public ArrayList<Livro> getLivros() {
        return livros;
    }

    public void setLivros(ArrayList<Livro> livros) {
        this.livros = livros;
    }
}
