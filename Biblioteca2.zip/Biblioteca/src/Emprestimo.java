import java.util.ArrayList;
import java.util.Date;

public class Emprestimo {
    private Cliente cliente;
    private Livro livro;
    private Date retirada;
    private Date devolucao;
    private static int qtd;
    //base para retirada do numero automatico

    private static ArrayList<Emprestimo> emprestimos = new ArrayList<>();

    public static String emprestarLivro(){
        return "Livro emprestado!";
    }

}
