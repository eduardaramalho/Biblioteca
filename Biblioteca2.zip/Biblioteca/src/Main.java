import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Usuario> listaUsuarios = new ArrayList<>();

    public static void main(String[] args) {
       Cliente cliente = new Cliente(1232, 30, 1650, "Waleska");
       Funcionario funcionario = new Funcionario(1234, 3625, 18, "Vend", 1560, "Eduard");

       Usuario.listaUsuarios.add(cliente);
       Usuario.listaUsuarios.add(funcionario);

       Funcionario usuario = Usuario.validaLogin();
       System.out.println(usuario.menu());


    }

    public static Usuario login(long usuario, int senha){

        return null;
    }

}
