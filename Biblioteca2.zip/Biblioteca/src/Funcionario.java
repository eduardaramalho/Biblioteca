import java.util.ArrayList;

public class Funcionario extends Usuario {

    private String cargo;
    private long cpf;
    private int idade;
    private int matricula;

    public Funcionario(int senha, long cpf, int idade, String cargo, int matricula, String nome) {
        super(cpf, idade, senha, nome);
        this.cargo = cargo;
        this.cpf = cpf;
        this.idade = idade;
        this.matricula = matricula;
    }

    public String menu(){
        System.out.println("1 - Ver livros" +
                "\n2 - Ver livros emprestados" +
                "\n3 - Emprestar livro" +
                "\n4 - Cadastrar livro" +
                "\n5 - Cadastrar autor" +
                "\n6 - Cadastrar editora" +
                "\n7 - Cadastrar coleção" +
                "\n8 - Cadastrar cliente");
        int opcao = sc.nextInt();
        switch (opcao){
            case 1:
                System.out.println(Livro.getLivros());
                break;
            case 2:
                System.out.println(verLivrosEmprestados());
                break;
            case 3:
                System.out.println(Emprestimo.emprestarLivro());
                break;
            case 4:
                System.out.println(cadastrarLivro());
                break;
            case 5:
                System.out.println(cadastrarAutor());
                break;
            case 6:
                System.out.println(cadastrarEditora());
                break;
            case 7:
                System.out.println(cadastrarColecao());
                break;
            case 8:
                System.out.println(cadastrarCliente());
                break;
            default:
                System.out.println("Opção inválida.");
        }
        return null;
    }

    @Override
    public ArrayList<Livro> verLivrosEmprestados() {
        return new ArrayList<>();
    }

    public String cadastrarLivro(){
        System.out.println("Livro: ");
        String livro = sc.next();
        System.out.println("Categoria: ");
        String categoria = sc.next();

      //  Livro livro = new Livro(Categoria.ROMANCE);

        listaLivros.add();
        return "Livro cadastrado com sucesso!";
    }

    public String cadastrarAutor(){
        return "Autor cadastrado com sucesso!";
    }

    public String cadastrarEditora(){
        return "Editora cadastrada com sucesso!";
    }

    public String cadastrarColecao(){
        return "Coleção cadastrada com sucesso!";
    }

    public String cadastrarCliente(){
        return "Cliente cadastrado com sucesso!";
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
}
