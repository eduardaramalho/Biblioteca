import java.util.ArrayList;
import java.util.Scanner;

public abstract class Usuario extends Pessoa {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Funcionario> listaUsuarios = new ArrayList<>();
    static ArrayList<Livro> listaLivros = new ArrayList<>();

    private long cpf;
    private int idade;
    private int senha;

    public abstract String menu();

    public ArrayList<Livro> verLivros(){
        return new ArrayList<>();
    }
    public abstract ArrayList<Livro> verLivrosEmprestados();
    public String emprestarLivro(){
        return "Livro emprestado com sucesso!";
    }

    public Usuario(long cpf, int idade, int senha, String nome) {
        super(nome);
        this.cpf = cpf;
        this.idade = idade;
        this.senha = senha;
    }

    public static Funcionario validaLogin() {
        System.out.println("CPF: ");
        long cpf = sc.nextLong();
        System.out.println("Senha: ");
        int senha = sc.nextInt();

        for(int i = 0; i < listaUsuarios.size(); i++){
            if(cpf == listaUsuarios.get(i).getCpf() && senha == listaUsuarios.get(i).getSenha()){
                return listaUsuarios.get(i);
            }
        }
        return null;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public int getSenha() { return senha; }

    public void setSenha(int senha) { this.senha = senha; }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
}
