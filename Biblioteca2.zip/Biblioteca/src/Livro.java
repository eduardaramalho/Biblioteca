import java.util.ArrayList;
import java.util.Date;

public class Livro {
    private int isbn;
    private int qtdPg;
    private String titulo;
    private Autor autor;
    private Categoria categoria;
    private Editora editora;
    private Date publicacao;

    private static ArrayList<Livro> livros = new ArrayList<>();

    public Livro(Categoria categoria) {
        this.categoria = categoria;
    }

    public static void main(String[] args) {
       Livro livro = new Livro (Categoria.SUSPENSE);
        System.out.println("Categoria: " + livro.categoria);
    }

    public static ArrayList<Livro> getLivros() {
        return livros;
    }

    public static void setLivros(ArrayList<Livro> livros) {
        Livro.livros = livros;
    }
}
