public class Autor extends Pessoa{
    private String nome;

    public Autor(String nome) {
        super(nome);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }


}
